<section id="vision">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-6">
                <div class="about_content">
                    <h2>Nuestra Visión</h2>
                    <br>
                    <p class="text-justify"> Ser una empresa líder en las Áreas Eléctrica, Instrumentación y Automatización, reconocida a nivel nacional, que se distinga por la calidad de sus servicios y productos, a fin de exceder las expectativas de nuestros clientes, con personal calificado y capacitado, respetuosos de la protección del medio ambiente y la seguridad de nuestros trabajadores</p>
                    <br><br>
                    <div class="hidden-sm hidden-xs">
                        <br>
                        <br>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-lg-offset-1">
                <div class="about_banner">
                   <div class="hidden-sm hidden-xs">
                    <br><br>
                   </div>
                    <img src="<?php echo HTML_DIR; ?>Vistas/images/vision.png" alt="" />
                    <br><br>
                </div>
            </div>
        </div>
    </div>
</section>