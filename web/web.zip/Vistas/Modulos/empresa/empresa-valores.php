<section id="valores">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-6">
                <div class="about_content">
                    <h2>Nuestros Valores</h2>
                    <br>
                    <p>Electric Systems, guiará sus acciones de acuerdo con los siguientes valores:
                    	<ul>
                    		<li>Honestidad</li>
							<li>Responsabilidad</li>
							<li>Trabajo en Equipo</li>
							<li>Compromiso</li>
							<li>Disciplina</li>
                            <li>Puntualidad</li>
                    	</ul>
                    </p>
                    <br>
                    <div class="hidden-sm hidden-xs">
                        <br><br>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-lg-offset-1">
                <div class="about_banner">
                   <div class="hidden-sm hidden-xs">
                        <br><br><br>
                   </div>
                    <img src="<?php echo HTML_DIR; ?>Vistas/images/valores.png" alt="" />
                    <br><br><br>
                </div>
            </div>
        </div>
    </div>
</section>