<!-- Contact form end -->
<div id="respuestaMensaje">
</div>
<section id="contact_form">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Su pregunta es importante para nosotros</h2>
                <h2 class="second_heading" style="font-size: 30px;">¡LE AGRADECEMOS POR ELLO, ESCRIBANOS!</h2>
            </div>
            <form role="form" id="formularioContacto" class="form-inline text-right col-md-6" >
                <div class="form-group">
                    <input type="text" class="form-control" id="txtNombres" placeholder="Nombres" required>
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" id="txtEmail" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <textarea class="form-control" rows="5" id="txtMensaje" placeholder="Mensaje" required></textarea>
                </div>
                <button type="submit" id="btnEnviarCorreo" class="btn submit_btn">Enviar</button>
            </form>             
        </div>
    </div>
</section>
