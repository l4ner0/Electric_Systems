<div id="notfound">
	<div class="notfound">
		<div class="notfound-404">
			<div></div>
			<h1>404</h1>
		</div>
		<h2>Página no encontrada</h2>
		<p>La página que está buscando podría haber sido eliminada o no está disponible en estos momentos.</p>
		<a href="inicio">Inicio</a>
	</div>
</div>

