<section id="" class="productos">
    <div class="container">
        <h2 class="titulo-producto">FABRICACION DE BANDEJAS PORTACABLES</h2>
        <div class="row">
            <div class="col-md-8">
                <div class="service_item">
                    <p>Somos fabricantes de bandejas portacables para la industria y comercio en general.</p>
                     <p>Nuestras bandejas son fabricadas en planchas de acero galvanizadas, galvanizados en caliente para los dos tipos:</p>
                     <ul>
                         <li>Bandeja lisa tipo canal en formato de 2.4 mt.</li>
                         <li>Bandeja tipo escalerilla en formato de 2.4 mt.</li>
                         <li>Accesorios para derivación de bandeja (curvas verticales interior y exterior, horizontal, derivación T).</li>
                     </ul>
                </div>
            </div>
            <div class="col-md-4"> 
               <img src="<?php echo HTML_DIR; ?>Vistas/images/productos/bandejaPortacableLisoCanal.png" alt="Imagen Producto" /> 
            </div>
        </div>
    </div>
</section>
<br><br><br>