<section id="" class="productos">
    <div class="container">
        <h2 class="titulo-producto">PRODUCTO N°X</h2>
        <div class="row">
            <div class="col-md-8">
                <div class="service_item">
                    <p>Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento</p>
                     <p>Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento Escribir aqui un argumento</p>
                     <ul>
                         <li>Escribir aqui un argumento</li>
                         <li>Escribir aqui un argumento</li>
                         <li>Escribir aqui un argumento</li>
                         <li>Escribir aqui un argumento</li>
                         <li>Escribir aqui un argumento</li>
                         <li>Escribir aqui un argumento</li>
                     </ul>
                </div>
            </div>
            <div class="col-md-4"> 
               <img src="<?php echo HTML_DIR; ?>Vistas/images/ejemploProducto.jpg" alt="Our Services" /> 
            </div>
        </div>
    </div>
</section>
<br><br><br>