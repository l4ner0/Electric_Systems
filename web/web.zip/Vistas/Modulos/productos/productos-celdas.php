<section id="" class="productos">
    <div class="container">
        <h2 class="titulo-producto">FABRICACION DE CELDAS EN MEDIA TENSION</h2>
        <div class="row">
            <div class="col-md-8">
                <div class="service_item">
                    <p>Somos fabricantes de celdas en media tensión hasta 24 kV en los siguientes diseños:</p>
                     <ul>
                         <li>Celda de remonte.</li>
                         <li>Celdas de medición.</li>
                         <li>Celdas de llegada.</li>
                         <li>Celdas de salida.</li>
                         <li>Celdas de transformación.</li>
                     </ul>
                     <p>Desarrollamos la integración de las celdas y equipamiento. Desarrollo de Protocolo de pruebas eléctricas y planos.</p>
                </div>
            </div>
            <div class="col-md-4"> 
               <img src="<?php echo HTML_DIR; ?>Vistas/images/ejemploProducto.jpg" alt="Our Services" /> 
            </div>
        </div>
    </div>
</section>
<br><br><br>