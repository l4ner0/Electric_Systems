<?php
    include('Vistas/Modulos/inicio/carrusel.php');
?>

<!-- empresa -->
<?php
    include('Vistas/Modulos/inicio/empresa.php');
?>
<!-- empresa end -->

<!-- por-que-elegirnos -->
<?php
    include('Vistas/Modulos/inicio/por-que-elegirnos.php');
?>
<!-- por-que-elegirnos -->

<!-- Productos -->
<?php
    include('Vistas/Modulos/inicio/productos.php');
?>
<!-- Productos end -->

<!-- servicios -->
<?php
    include('Vistas/Modulos/inicio/servicios.php');
?>
<!-- servicios end -->

<!-- Testimonial -->

<!-- Testimonial end -->

