<section id="" class="servicios">
    <div class="container">
        <h2 class="titulo-servicio">OTROS SERVICIOS</h2>
        <div class="row">
            <div class="col-md-8">
                <div class="service_item">
	                 <ul>
	                     <li>Instalación de redes de aire comprimido.</li>
	                     <li>Instalación de sistema de alumbrado de emergencia normal y antideflagrante (antiexplosion).</li>
	                     <li>Levantamiento de información, elaboración y actualización de planos eléctricos en general.</li>
	                     <li>Levantamiento de información y elaboración de planos eléctricos de tableros eléctricos, listado de materiales, de equipos eléctricos y electrónicos.</li>
	                     <li>Fabricación de soportes metálicos para bandejas, tableros y otros.</li>
	                     <li>Asesoría de expediente técnico para la inspección del Instituto Nacional de Defensa Civil (INDECI).</li>
	                     <li>Pintado de salas eléctricas y tableros eléctricos.</li>
	                     <li>Instalación y mantenimiento de pararrayos para celdas de Media tensión.</li>
	                 </ul>
                </div>
            </div>
            <div class="col-md-4"> 
               <img src="<?php echo HTML_DIR; ?>Vistas/images/ejemploServicio.png" alt="Our Services" /> 
            </div>
        </div>
    </div>
</section>
<br><br><br>