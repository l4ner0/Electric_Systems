<?php

/*Constantes para PHPMailer*/

define('PHPMAILER_HOST','smtp.gmail.com');
define('PHPMAILER_USER','Diegourbina1284@gmail.com');
define('PHPMAILER_PASS','yjnohiayidzjcjxb');
define('PHPMAILER_PORT',587);


/*Constantes para dirección*/

//define("HTML_DIR","");
//define("HTML_DIR","https://localhost/Repos_web/Electric_Systems/web/");
//define("HTML_DIR","https://www.villa-book.com/");
define("HTML_DIR","http://node78587-env-0836362.whelastic.net/ROOT-546/");